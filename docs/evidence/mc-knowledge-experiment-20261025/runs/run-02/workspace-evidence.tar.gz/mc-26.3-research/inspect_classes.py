import io
import pathlib
import sys
import zipfile

ROOT = pathlib.Path(__file__).parent
sys.path.insert(0, str(ROOT / 'python-libs'))
from jawa.cf import ClassFile


def describe(c):
    if hasattr(c, 'class_') and hasattr(c, 'name_and_type'):
        n = c.name_and_type
        return f'{c.class_.name.value}.{n.name.value}{n.descriptor.value}'
    if hasattr(c, 'name'):
        return c.name.value
    if hasattr(c, 'string'):
        return repr(c.string.value)
    if hasattr(c, 'value'):
        return str(c.value)
    return repr(c)


with zipfile.ZipFile(ROOT / 'vanilla-26.3.jar') as z:
    for name in sys.argv[1:]:
        cls = ClassFile(io.BytesIO(z.read(name.replace('.', '/') + '.class')))
        out = [f'class {cls.this.name.value} extends {cls.super_.name.value}', '']
        for method in cls.methods:
            out.append(method.name.value + method.descriptor.value)
            if method.code:
                for ins in method.code.disassemble():
                    operands = []
                    for operand in ins.operands:
                        if isinstance(operand, dict):
                            operands.append(repr(operand))
                        elif operand.op_type.name == 'CONSTANT_INDEX':
                            operands.append(describe(cls.constants[operand.value]))
                        elif operand.op_type.name == 'BRANCH':
                            operands.append(f'{ins.pos + operand.value} (offset {operand.value:+})')
                        else:
                            operands.append(str(operand.value))
                    out.append(f'  {ins.pos:4}: {ins.mnemonic:20} ' + ' '.join(operands))
            out.append('')
        dest = ROOT / (name.rsplit('.', 1)[-1] + '.bytecode.txt')
        dest.write_text('\n'.join(out) + '\n')
        print(dest)
