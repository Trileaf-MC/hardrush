import sys
import io
import pathlib
import zipfile

ROOT = pathlib.Path(__file__).parent
sys.path.insert(0, str(ROOT / 'python_lib'))
from jawa.cf import ClassFile

def describe(c):
    if hasattr(c, 'class_') and hasattr(c, 'name_and_type'):
        return f'{c.class_.name.value}.{c.name_and_type.name.value}{c.name_and_type.descriptor.value}'
    if hasattr(c, 'name_and_type'):
        return f'dynamic[{c.bootstrap_method_attr_index}] {c.name_and_type.name.value}{c.name_and_type.descriptor.value}'
    if hasattr(c, 'name'):
        return c.name.value
    if hasattr(c, 'string'):
        return repr(c.string.value)
    if hasattr(c, 'value'):
        return repr(c.value)
    return repr(c)

with zipfile.ZipFile(ROOT / 'server-inner.jar') as jar:
    for query in sys.argv[1:]:
        matches = [n for n in jar.namelist() if n.endswith('/' + query + '.class')]
        for name in matches:
            cf = ClassFile(io.BytesIO(jar.read(name)))
            lines = [f'CLASS {name}', f'EXTENDS {cf.super_.name.value}', 'FIELDS']
            lines.extend(f'  {f.name.value} {f.descriptor.value}' for f in cf.fields)
            for m in cf.methods:
                lines.append(f'\nMETHOD {m.name.value}{m.descriptor.value}')
                if m.code is None:
                    continue
                for ins in m.code.disassemble():
                    args = []
                    for op in ins.operands:
                        if isinstance(op, dict):
                            args.append(str({k: ins.pos + v for k, v in op.items()}))
                        elif op.op_type.name == 'BRANCH':
                            args.append(f'-> {ins.pos + op.value}')
                        elif op.op_type.name == 'CONSTANT_INDEX':
                            args.append(describe(cf.constants.get(op.value)))
                        else:
                            args.append(str(op.value))
                    lines.append(f'  {ins.pos:5} {ins.mnemonic:20} {" | ".join(args)}')
            path = ROOT / (query + '.bytecode.txt')
            path.write_text('\n'.join(lines) + '\n')
            print(path)
