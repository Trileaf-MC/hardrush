public abstract class Entity
   implements Nameable,
   EntityAccess,
   ScoreHolder,
   SyncedDataHolder,
   DataComponentGetter,
   ItemOwner,
   SlotProvider,
   DebugValueSource,
   TypedInstance<EntityType<?>> {
   public void baseTick() {
      ProfilerFiller profiler = Profiler.get();
      profiler.push("entityBaseTick");
      this.computeSpeed();
      this.inBlockState = null;
      if (this.isPassenger() && this.getVehicle().isRemoved()) {
         this.stopRiding();
      }

      if (this.boardingCooldown > 0) {
         this.boardingCooldown--;
      }

      this.handlePortal();
      if (this.canSpawnSprintParticle()) {
         this.spawnSprintParticle();
      }

      this.wasInPowderSnow = this.isInPowderSnow;
      this.isInPowderSnow = false;
      this.wasEyeInWater = this.isEyeInFluid(FluidTags.WATER);
      this.updateFluidInteraction();
      this.updateSwimming();
      if (this.level() instanceof ServerLevel serverLevel) {
         if (this.remainingFireTicks > 0) {
            if (this.fireImmune()) {
               this.clearFire();
            } else {
               if (this.remainingFireTicks % 20 == 0 && !this.isInLava()) {
                  this.hurtServer(serverLevel, this.damageSources().onFire(), 1.0F);
               }

               this.setRemainingFireTicks(this.remainingFireTicks - 1);
            }
         }
      } else {
         this.clearFire();
      }

      if (this.isInLava()) {
         this.fallDistance *= 0.5;
      }

      this.checkBelowWorld();
      if (!this.level().isClientSide()) {
         this.setSharedFlagOnFire(this.remainingFireTicks > 0);
      }

      this.firstTick = false;
      if (this.level() instanceof ServerLevel serverLevel && this instanceof Leashable) {
         Leashable.tickLeash(serverLevel, (Entity & Leashable)this);
      }

      profiler.pop();
   }
}
