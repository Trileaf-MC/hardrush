public class Wolf extends TamableAnimal implements NeutralMob {
   private void tryToTame(final Player player) {
      if (this.random.nextInt(3) == 0) {
         this.tame(player);
         this.navigation.stop();
         this.setTarget(null);
         this.setOrderedToSit(true);
         this.level().broadcastEntityEvent(this, (byte)7);
      } else {
         this.level().broadcastEntityEvent(this, (byte)6);
      }
   }
}
