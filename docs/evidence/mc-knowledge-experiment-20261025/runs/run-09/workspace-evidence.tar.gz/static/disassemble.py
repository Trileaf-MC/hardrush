import sys,zipfile,io,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).parent/'pydeps'))
from jawa.cf import ClassFile
from jawa.util.bytecode import OperandTypes
z=zipfile.ZipFile('26.3-client.jar')
def render(c,k):
 x=c.constants.get(k)
 if hasattr(x,'class_') and hasattr(x,'name_and_type'): return x.class_.name.value+'.'+x.name_and_type.name.value+x.name_and_type.descriptor.value
 if hasattr(x,'name_and_type'): return str(x)
 if hasattr(x,'name'): return x.name.value
 if hasattr(x,'string'): return repr(x.string.value)
 if hasattr(x,'value'): return repr(x.value)
 return str(x)
for n in sys.argv[1:]:
 if not n.endswith('.class'): n=n.replace('.','/')+'.class'
 c=ClassFile(io.BytesIO(z.read(n))); out=[]
 out.append('CLASS '+c.this.name.value+' EXTENDS '+c.super_.name.value)
 out.append('FIELDS\n'+'\n'.join(f.name.value+' '+f.descriptor.value for f in c.fields))
 for m in c.methods:
  out.append('\nMETHOD '+m.name.value+' '+m.descriptor.value)
  if not m.code: continue
  for ins in m.code.disassemble():
   ops=[]
   for o in ins.operands:
    if not hasattr(o,'op_type'): ops.append(str(o)); continue
    ops.append(render(c,o.value) if o.op_type==OperandTypes.CONSTANT_INDEX else ('->'+str(ins.pos+o.value) if o.op_type==OperandTypes.BRANCH else str(o.value)))
   out.append(f'{ins.pos:5} {ins.mnemonic:20} '+', '.join(ops))
 p=pathlib.Path('static')/(n.rsplit('/',1)[-1]+'.txt'); p.write_text('\n'.join(out)); print(p)
