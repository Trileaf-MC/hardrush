# Java 版 26.3 原版机制证据

本目录由本次调查从本机 Fabric Loom 缓存重新提取生成。未读取既有调查报告、聊天记录、个人记忆或其他实验目录；未启动子代理、游戏客户端或服务器。原缓存仅只读访问。

- `version.json`：原版 JAR 内的版本信息，id=26.3，stable=true。
- `provenance.json`：输入路径、官方服务端下载 URL、SHA-1/SHA-256，以及服务端外层包与内部版本清单的匹配结果。
- `classes/`：为查证而提取的原版 class。
- `src/`：用 Vineflower 1.12.0 重新反编译的相关 Java 文件。
- `bytecode/`：JDK javap 对 Skeleton、ConversionTracker、Wolf 的独立反汇编，用于复核反编译结果。

关键入口：

1. `src/net/minecraft/world/entity/monster/skeleton/Skeleton.java`：细雪条件、140/300 参数、抖动、tick 顺序和免疫冻结。
2. `src/net/minecraft/world/entity/ConversionTracker.java`：服务端/存活/AI 条件，准备计数 >=140，转化倒计时减至 <0，离雪重置，保留装备的转化调用。
3. `src/net/minecraft/world/entity/animal/wolf/Wolf.java` 的 registerGoals：野生和驯服狼共用 AbstractSkeleton 目标规则；坐下优先级与受伤解除坐下。
4. `src/net/minecraft/world/entity/monster/skeleton/Stray.java`：Stray extends AbstractSkeleton。
5. `src/net/minecraft/world/entity/ai/goal/target/NonTameRandomTargetGoal.java`：仅该规则额外要求未驯服；不可把此条件套用到骷髅类目标规则。

逐 tick 边界：ConversionTracker 的准备计数构造初值为 0，离开细雪时设为 -1。通常从雪外进入时，141 次连续雪内检查使其从 -1 增到 140，并设置 conversionTime=300；之后 301 次雪内检查才减到 -1 并转化。因此通常路径共 442 次有效检查，参数的日常概括仍是约 7+15=22 秒。若准备计数初态为 0，则准备阶段是 140 次检查。此为静态代码推导，不是从画面接触起测得的秒表结果。

复核反编译命令示例（需要可用的 Java）：

```sh
java -jar /path/to/vineflower-1.12.0.jar -log=WARN evidence-26.3/classes /tmp/mc263-recheck
javap -p -c evidence-26.3/classes/net/minecraft/world/entity/ConversionTracker.class
```
